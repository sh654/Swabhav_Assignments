package com.mvc.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mvc.model.DbUtil;
import com.mvc.models.User;

public class UserDao {

    public void addUser(User user) throws Exception {
        String sql = "INSERT INTO Users (username, password, role) VALUES (?, ?, ?)";

        try (Connection conn = DbUtil.getConnection(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getRole().toString());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error adding user", e);
        }
    }
    
    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/aurobank", "root", "root");
    }
    
    public void updateUserProfile(String username, String firstName, String lastName, String password) throws Exception {
        String sql = "UPDATE customer SET firstname = ?, lastname = ?, password = ? WHERE userid = ?";
        try (Connection conne = DbUtil.getConnection();
             PreparedStatement stmt = conne.prepareStatement(sql)) {
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, password);
            stmt.setString(4, username);
            stmt.executeUpdate();
        }
    }
}



    
    

