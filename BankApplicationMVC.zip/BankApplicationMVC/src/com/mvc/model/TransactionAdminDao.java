package com.mvc.model;

import com.mvc.models.Transaction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TransactionAdminDao {
	
	 static {
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	            throw new RuntimeException("MySQL JDBC Driver not found.");
	        }
	    }

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/aurobank", "root", "root");
    }

    public List<Transaction> getAllTransactions() throws SQLException {
        List<Transaction> transactions = new ArrayList<>();

        String query = "SELECT t.transaction_type, t.amount, t.Date AS transaction_date, " +
                       "s.accountsnumber AS sender_account_number, " +
                       "r.accountsnumber AS receiver_account_number " +
                       "FROM aurobank.transactions t " +
                       "JOIN aurobank.accounts s ON t.accountsid = s.accountsid " +
                       "LEFT JOIN aurobank.accounts r ON t.receiver_account_number = r.accountsnumber";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Transaction transaction = new Transaction();
                transaction.setTransactionType(rs.getString("transaction_type"));
                transaction.setAmount(rs.getBigDecimal("amount"));
                transaction.setReceiverAccountNumber(rs.getString("receiver_account_number"));
                transaction.setDate(rs.getTimestamp("transaction_date"));
                transaction.setAccountNumber(rs.getString("sender_account_number"));
                transactions.add(transaction);
            }
            
            for(Transaction transaction: transactions) {
            	System.out.println(transaction);
            }
        }

        return transactions;
    }
}
