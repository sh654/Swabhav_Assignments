package com.mvc.enums;

public enum TransactionType {
    DEBIT,
    CREDIT,
    TRANSFER
}