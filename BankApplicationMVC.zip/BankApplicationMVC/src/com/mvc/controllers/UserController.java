package com.mvc.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.model.UserDao;
import com.mvc.models.User;

@WebServlet("/UserController")
public class UserController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private UserDao userDao;

    public UserController() {
        super();
        userDao = new UserDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String roleStr = request.getParameter("role");

        
       
        // Convert the role string to enum
        User.Role role = User.Role.fromString(roleStr);

        // Create a new User object
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setRole(role);

        // Add the user to the database
        try {
			userDao.addUser(user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        // Redirect to a success page or back to the add customer form
        response.sendRedirect("addNewCustomer.jsp?success=true");
    }
}



